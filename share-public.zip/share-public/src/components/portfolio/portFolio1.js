import React from 'react'
import Stocks from '../stocks/stocks'

const PortFolio1 = () => {
  return (
    <>
        <Stocks/>
    </>
  )
}

export default PortFolio1