const Data5 = [
    {
        id: 5,
        name: 'Amazon',
        symbol: 'HLMP',
        low: 610.5,
        high: 650.5,
        close: 629.5,
        number: 1
    },
]

export default Data5