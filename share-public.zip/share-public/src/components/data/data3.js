const Data3 = [
    {
        id: 3,
        name: 'Google',
        symbol: 'CMGL',
        low: 247.5,
        high: 250.5,
        close: 249.5,
        number: 1
    },
]

export default Data3