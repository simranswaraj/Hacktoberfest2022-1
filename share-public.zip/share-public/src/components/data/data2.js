const Data2 = [
    {
        id: 2,
        name: 'Microsoft',
        symbol: 'KMPL',
        low: 170.5,
        high: 209.5,
        close: 195.5,
        number: 1
    },
]

export default Data2