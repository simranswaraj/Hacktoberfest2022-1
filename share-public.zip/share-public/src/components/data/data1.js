const Data1 = [
    {
        id: 1,
        name: 'IBM',
        symbol: 'AAPL',
        low: 147.5,
        high: 150.5,
        close: 149.5,
        number: 1
    },
]

export default Data1