const Data4 = [
    {
        id: 4,
        name: 'Accenture',
        symbol: 'PPHL',
        low: 300.5,
        high: 340.5,
        close: 335.5,
        number: 1
    },
]

export default Data4