const Data = [
    {
        id: 1,
        name: 'IBM',
        symbol: 'AAPL',
        low: 147.5,
        high: 150.5,
        close: 149.5,
        number: 5
    },
    {
        id: 2,
        name: 'Microsoft',
        symbol: 'KMPL',
        low: 170.5,
        high: 209.5,
        close: 195.5,
        number: 10
    },
    {
        id: 3,
        name: 'Google',
        symbol: 'CMGL',
        low: 247.5,
        high: 250.5,
        close: 249.5,
        number: 7
    },
    {
        id: 4,
        name: 'Accenture',
        symbol: 'PPHL',
        low: 300.5,
        high: 340.5,
        close: 335.5,
        number: 5
    },
    {
        id: 5,
        name: 'Amazon',
        symbol: 'HLMP',
        low: 610.5,
        high: 650.5,
        close: 629.5,
        number: 2
    },
]

export default Data